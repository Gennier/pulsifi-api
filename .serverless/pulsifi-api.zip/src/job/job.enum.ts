export enum JobStatus {
  active = 'active',
  inactive = 'inactive',
}
