export enum UserStatus {
  active = 'active',
  inactive = 'inactive',
}

export enum UserRole {
  recruiter = 'recruiter',
  talent = 'talent',
}
